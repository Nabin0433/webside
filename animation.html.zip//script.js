// Created Using Easy HTML v1.4.5
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml

// var 
// c= ducument.getElementById("jb");
// var ctx=c.getcontext("jb");
// ctx.shadowblur=5;
// ctx.shadowoffsety=20;
// ctx.shadowcolor="red";
// ctx.fillstyle="black";
// ctx.fillrect(20,20,100,80);
